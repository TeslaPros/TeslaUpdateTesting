# Tesla SS Tools - Startup Animation Prototype

This is an isolated test. It does not edit, start, or connect to the production Tesla SS Tools project or GitHub.

## Start from CMD

Open CMD, go to this folder, and run:

```cmd
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "TeslaStartupTest.ps1"
```

The script resolves every asset relative to its own location with `$PSScriptRoot`, so it also works when CMD was opened in another directory and the full script path is supplied.

## Files

- `TeslaStartupTest.ps1` - WPF launcher, animation controller, transition, and temporary test GUI.
- `assets/car-off.png` - transparent photorealistic vehicle with the lamps off.
- `assets/car-on.png` - matching transparent vehicle with realistic LED headlights and light bloom.
- `assets/fog.png` - transparent low-lying atmospheric mist used twice for parallax depth.

## Sequence

1. An almost-black borderless fullscreen scene is held briefly.
2. The cached `car-off.png` layer fades in above a subtle floor reflection.
3. `TESLA SS TOOLS` appears behind the car at low opacity.
4. `car-on.png` crossfades over the same vehicle while two restrained WPF light layers add spread and bloom.
5. Two copies of `fog.png` drift in opposite directions at low opacity; this is ambient cold mist, not exhaust.
6. WPF spline keyframes animate translation, scale, slight rotation, and motion blur. The first movement is slow and the final pass accelerates strongly.
7. The title fades as the car begins moving.
8. A blurred neutral light streak and dark veil connect the passing car to the already-created GUI layer.
9. The temporary GUI fades in inside the same WPF window, preventing a white flash or abrupt window swap.

The intro lasts about 3.4 seconds. Press `Esc` during the intro to skip it. In the mock GUI, use **Replay animation**, **Close**, or press `Esc` to close.

## Technology

The prototype uses only Windows PowerShell, built-in .NET/WPF, XAML, cached `BitmapImage` objects, a WPF `Storyboard`, `DoubleAnimationUsingKeyFrames`, spline easing, transforms, opacity masks, and blur/drop-shadow effects. No internet connection, Python, Node.js, Electron, FFmpeg, package installation, or external media player is needed.

## Later production integration

If this prototype is approved, only the asset preload, intro XAML/storyboard, and completion callback need to be moved into the real Tesla SS Tools startup path. The temporary mock GUI must then be replaced by the existing production window. That integration is intentionally not included here.
